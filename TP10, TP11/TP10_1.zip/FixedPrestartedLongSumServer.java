package fr.upem.net.tcp;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FixedPrestartedLongSumServer {

    private static final Logger logger = Logger.getLogger(FixedPrestartedLongSumServer.class.getName());
    private static final int BUFFER_SIZE = 1024; 
    private final ServerSocketChannel serverSocketChannel;
    private final int permit;

    public FixedPrestartedLongSumServer(int port, int permit) throws IOException {
        serverSocketChannel = ServerSocketChannel.open();
        serverSocketChannel.bind(new InetSocketAddress(port)); 
        this.permit = permit;
        logger.info(this.getClass().getName()
                + " starts on port " + port);
    }

    /**
     * Iterative server main loop
     *
     * @throws IOException
     */
    public void launch() throws IOException {
        
        logger.info("Server started");
        
        for (int i = 0; i < permit; i++) {
            
            Thread thread = new Thread(() -> {
                 while(!Thread.interrupted()) {
                     SocketChannel client = null;
                     try {
                         client = serverSocketChannel.accept();
                         while (true) {
                             try {
                                 logger.info("Connection accepted from " + client.getRemoteAddress());
                                 ByteBuffer intBuffer = ByteBuffer.allocate(Integer.BYTES);
                                 ByteBuffer longBuffer = ByteBuffer.allocate(Long.BYTES);
                                 // Get number of long
                                 intBuffer.clear();
                                 readFully(client, intBuffer);
                                 intBuffer.flip();
                                 if (intBuffer.remaining() != Integer.BYTES) {
                                    throw new IOException();
                                 }
                                 int numberOfLong = intBuffer.getInt();
                                 System.out.println(numberOfLong);
                                 // Compute sum
                                 long sum = 0;
                                 while (numberOfLong != 0) {
                                     longBuffer.clear();
                                     readFully(client, longBuffer);
                                     longBuffer.flip();
                                     if (longBuffer.remaining() != Long.BYTES) {
                                        throw new IOException();
                                     }
                                     sum += longBuffer.getLong();                               
                                     numberOfLong--;
                                 }
                                 longBuffer.clear();
                                 longBuffer.putLong(sum);
                                 longBuffer.flip();
                                 client.write(longBuffer);                      
                             } catch (IOException exception) {
                                 break;
                             }
                         }
                     } catch (IOException exception) {
                         logger.info("IOException trying to accept client.");
                     } finally {
                         silentlyClose(client);
                     }
                 }              
            });
            
            thread.start();
            
        }
        
    }

    /**
     * Close a SocketChannel while ignoring IOExecption
     *
     * @param sc
     */

    private void silentlyClose(SocketChannel sc) {
        if (sc != null) {
            try {
                sc.close();
            } catch (IOException e) {
                // Do nothing
            }
        }
    }

    static boolean readFully(SocketChannel sc, ByteBuffer bb) throws IOException {
        while(bb.hasRemaining()) {
            if (sc.read(bb)==-1){
                logger.info("Input stream closed");
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) throws NumberFormatException, IOException {
        FixedPrestartedLongSumServer server = new FixedPrestartedLongSumServer(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
        server.launch();
    }
}
